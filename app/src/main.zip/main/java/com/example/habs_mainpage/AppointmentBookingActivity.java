package com.example.habs_mainpage;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AppointmentBookingActivity extends AppCompatActivity {

    TextView tvDoctorName, tvSpecialization, tvFee, tvTiming;
    DatePicker datePicker;
    GridView gridSlots;
    EditText etReason, etPatientName, etContact;
    RadioGroup rgConsultationType; // Online / In-person selection
    CheckBox cbConsent;
    Button btnConfirm;

    String[] generatedSlots;
    String selectedSlot = null;

    // Firebase reference
    DatabaseReference appointmentRef, counterRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appointmentbooking);

        // Bind UI elements
        tvDoctorName = findViewById(R.id.tvDoctorName);
        tvSpecialization = findViewById(R.id.tvSpecialization);
        tvFee = findViewById(R.id.tvFee);
        tvTiming = findViewById(R.id.tvTiming);
        datePicker = findViewById(R.id.datePicker);
        gridSlots = findViewById(R.id.gridSlots);
        etReason = findViewById(R.id.etReason);
        etPatientName = findViewById(R.id.etPatientName);
        etContact = findViewById(R.id.etContact);
        rgConsultationType = findViewById(R.id.rgConsultationType);
        cbConsent = findViewById(R.id.cbConsent);
        btnConfirm = findViewById(R.id.btnConfirm);

        // Prevent past dates
        datePicker.setMinDate(System.currentTimeMillis());

        // Firebase references
        appointmentRef = FirebaseDatabase.getInstance().getReference("Appointments");
        counterRef = FirebaseDatabase.getInstance().getReference("AppointmentCounter");

        // Get doctor details from intent
        String name = getIntent().getStringExtra("doctorName");
        String specialization = getIntent().getStringExtra("specialization");
        String fee = getIntent().getStringExtra("fee");
        String timing = getIntent().getStringExtra("timing");
        int consultationTime = getIntent().getIntExtra("consultationTime", 15);

        // Set doctor info
        tvDoctorName.setText("Dr. " + name);
        tvSpecialization.setText("Specialization: " + specialization);
        tvFee.setText("Fee: Rs. " + fee);
        tvTiming.setText("Available: " + timing);

        // Generate slots dynamically
        generatedSlots = generateSlots(timing, consultationTime);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.time_slot, R.id.tvSlot, generatedSlots);
        gridSlots.setAdapter(adapter);

        // Slot selection with highlight
        gridSlots.setOnItemClickListener((adapterView, view, i, l) -> {
            selectedSlot = generatedSlots[i];
            for (int j = 0; j < adapterView.getChildCount(); j++) {
                adapterView.getChildAt(j).setActivated(false);
            }
            view.setActivated(true);
            Toast.makeText(this, "Selected: " + selectedSlot, Toast.LENGTH_SHORT).show();
        });

        // Confirm button click
        btnConfirm.setOnClickListener(v -> {
            if (!cbConsent.isChecked()) {
                Toast.makeText(this, "Please agree to the terms", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedSlot == null) {
                Toast.makeText(this, "Please select a time slot", Toast.LENGTH_SHORT).show();
                return;
            }

            String patientName = etPatientName.getText().toString().trim();
            String contact = etContact.getText().toString().trim();
            String reason = etReason.getText().toString().trim();

            if (patientName.isEmpty() || contact.isEmpty()) {
                Toast.makeText(this, "Enter patient name & contact", Toast.LENGTH_SHORT).show();
                return;
            }

            int selectedTypeId = rgConsultationType.getCheckedRadioButtonId();
            if (selectedTypeId == -1) {
                Toast.makeText(this, "Please select consultation type", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ Fixed line according to XML IDs (rbTele / rbInPerson)
            String typePrefix;
            String appointmentType;
            if (selectedTypeId == R.id.rbOnline) {
                typePrefix = "O"; // Online
                appointmentType = "Online";
            } else {
                typePrefix = "I"; // In-person
                appointmentType = "In-person";
            }

            // Get selected date
            Calendar selectedDate = Calendar.getInstance();
            selectedDate.set(datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth());
            String formattedDate = new SimpleDateFormat("dd MMM yyyy", Locale.US).format(selectedDate.getTime());

            // Save appointment in Firebase
            saveAppointmentToFirebase(patientName, contact, reason, name, specialization, fee, formattedDate, selectedSlot, typePrefix, appointmentType);
        });
    }

    // Save appointment with global sequence ID (O1, I2, O3...)
    private void saveAppointmentToFirebase(String patientName, String contact, String reason,
                                           String doctorName, String specialization, String fee,
                                           String date, String slot, String typePrefix, String appointmentType) {

        // Get current counter, increment, and save new ID
        counterRef.get().addOnSuccessListener(snapshot -> {
            long currentCount = 0;
            if (snapshot.exists()) {
                currentCount = snapshot.getValue(Long.class);
            }

            long newCount = currentCount + 1;
            counterRef.setValue(newCount);

            // Custom ID (O1, I2, ...)
            String customId = typePrefix + newCount;

            Map<String, Object> appointmentData = new HashMap<>();
            appointmentData.put("appointmentId", customId);
            appointmentData.put("doctorName", doctorName);
            appointmentData.put("specialization", specialization);
            appointmentData.put("fee", fee);
            appointmentData.put("date", date);
            appointmentData.put("slot", slot);
            appointmentData.put("patientName", patientName);
            appointmentData.put("contact", contact);
            appointmentData.put("reason", reason);
            appointmentData.put("status", "Pending");
            appointmentData.put("type", appointmentType);

            // ✅ Debug log to check data being saved
            Log.d("FirebaseDebug", "Appointment Saved: " + appointmentData.toString());

            appointmentRef.child(customId).setValue(appointmentData)
                    .addOnSuccessListener(aVoid ->
                            Toast.makeText(this, "✅ Appointment " + customId + " saved!", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }).addOnFailureListener(e ->
                Toast.makeText(this, "Counter fetch failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // Slot generator function
    private String[] generateSlots(String timing, int consultationMinutes) {
        try {
            String range = timing;

            if (!timing.contains("-")) {
                String t = timing.toLowerCase();
                if (t.contains("morning")) range = "09:00 AM - 12:00 PM";
                else if (t.contains("afternoon")) range = "12:00 PM - 04:00 PM";
                else if (t.contains("evening")) range = "04:00 PM - 08:00 PM";
                else return new String[0];
            }

            String[] parts = range.split("-");
            if (parts.length < 2) return new String[0];

            String startStr = parts[0].trim();
            String endStr = parts[1].trim();

            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.US);
            Date startDate = sdf.parse(startStr);
            Date endDate = sdf.parse(endStr);

            long consultMs = consultationMinutes * 60L * 1000L;
            List<String> slots = new ArrayList<>();

            Calendar cal = Calendar.getInstance();
            cal.setTime(startDate);
            Calendar calEnd = Calendar.getInstance();
            calEnd.setTime(endDate);

            while (cal.getTimeInMillis() + consultMs <= calEnd.getTimeInMillis()) {
                slots.add(sdf.format(cal.getTime()));
                cal.add(Calendar.MINUTE, consultationMinutes);
            }

            return slots.toArray(new String[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return new String[0];
        }
    }
}
