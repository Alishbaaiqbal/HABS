package com.example.habs_mainpage;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

//import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder> {

    private Context context;
    private final List<Doctor> doctorList;

    public DoctorAdapter(Context context, List<Doctor> doctorList) {
        this.context = context;
        this.doctorList = doctorList;
    }


    @Override
    public DoctorViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.doctorcard, parent, false);
        return new DoctorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(DoctorViewHolder holder, int position) {
        Doctor doctor = doctorList.get(position);

        holder.name.setText(doctor.getName());
        holder.specialization.setText(doctor.getSpecialization());
        holder.timing.setText(doctor.getTiming());
        holder.availability.setText(doctor.isAvailability() ? "Available" : "Not Available");
        holder.fee.setText("Rs. " + doctor.getFee());
        holder.consultationTime.setText(doctor.getConsultationTime() + " mins per patient");

        // Color for availability
        int color = doctor.isAvailability()
                ? context.getColor(android.R.color.holo_green_dark)
                : context.getColor(android.R.color.holo_red_dark);
        holder.availability.setTextColor(color);

        // Book button
        holder.btnBook.setOnClickListener(v -> {
            Intent intent = new Intent(context, AppointmentBookingActivity.class);
            intent.putExtra("doctorName", doctor.getName());
            intent.putExtra("specialization", doctor.getSpecialization());
            intent.putExtra("fee", doctor.getFee());
            intent.putExtra("timing", doctor.getTiming());
            intent.putExtra("consultationTime", doctor.getConsultationTime());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return doctorList.size();
    }

    public static class DoctorViewHolder extends RecyclerView.ViewHolder {
        TextView name, specialization, timing, availability, fee, consultationTime;
        Button btnBook;

        public DoctorViewHolder( View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tv_doctor_name);
            specialization = itemView.findViewById(R.id.tv_specialization);
            timing = itemView.findViewById(R.id.tv_timing);
            availability = itemView.findViewById(R.id.tv_availability);
            fee = itemView.findViewById(R.id.tv_fee);
            consultationTime = itemView.findViewById(R.id.tv_consultation_time);
            btnBook = itemView.findViewById(R.id.btn_book);
        }
    }
}