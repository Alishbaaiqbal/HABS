package com.example.habs_mainpage;

import com.google.firebase.database.PropertyName;

public class Doctor {
    private String id;
    private String name;
    private String specialization;
    private String timing;
    private boolean availability;
    private String fee;
    private String consultationTime;

    // Required empty constructor for Firebase
    public Doctor() { }

    public Doctor(String id, String name, String specialization, String timing,
                  boolean availability, String fee, String consultationTime) {
        this.id = id;
        this.name = name;
        this.specialization = specialization;
        this.timing = timing;
        this.availability = availability;
        this.fee = fee;
        this.consultationTime = consultationTime;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getSpecialization() { return specialization; }
    public String getTiming() { return timing; }

    @PropertyName("available")
    public boolean isAvailability() { return availability; }

    @PropertyName("fee")
    public String getFee() { return fee; }

    public String getConsultationTime() { return consultationTime; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
    public void setTiming(String timing) { this.timing = timing; }

    @PropertyName("available")
    public void setAvailability(boolean availability) { this.availability = availability; }

    @PropertyName("fee")
    public void setFee(String fee) { this.fee = fee; }

    public void setConsultationTime(String consultationTime) { this.consultationTime = consultationTime; }
}