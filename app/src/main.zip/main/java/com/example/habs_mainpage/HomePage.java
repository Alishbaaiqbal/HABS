package com.example.habs_mainpage;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

//import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HomePage extends AppCompatActivity implements OnMapReadyCallback {

    private static final String TAG = "HomePage";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    private static final String API_KEY = "AIzaSyDOvI7B1rs0ZZhDUNVNmRs83xaYtx__hX0";

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private TextView currentAddressTextView;

    private RecyclerView recyclerView;
    private HospitalAdapter adapter;
    private List<Hospital> hospitalList;

    // Map to store Firebase hospital IDs with their names
    private Map<String, String> firebaseHospitalIds = new HashMap<>();
    private boolean firebaseDataLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard);

        currentAddressTextView = findViewById(R.id.tv_current_address);
        recyclerView = findViewById(R.id.recycler_hospitals);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        hospitalList = new ArrayList<>();
        adapter = new HospitalAdapter(this, hospitalList);
        recyclerView.setAdapter(adapter);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Load Firebase hospital data first
        loadFirebaseHospitals();

        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map_fragment);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult result) {
                Location location = result.getLastLocation();
                if (location != null) {
                    updateMapAndFetchHospitals(location);
                }
            }
        };
    }

    // Load hospital names and IDs from Firebase
    private void loadFirebaseHospitals() {
        DatabaseReference hospitalsRef = FirebaseDatabase.getInstance()
                .getReference("Hospitals");

        Log.d(TAG, "Loading Firebase hospitals...");

        hospitalsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot snapshot) {
                Log.d(TAG, "Firebase hospitals count: " + snapshot.getChildrenCount());

                if (!snapshot.exists()) {
                    Log.e(TAG, "No hospitals in Firebase!");
                    Toast.makeText(HomePage.this,
                            "No hospitals in database",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                for (DataSnapshot hospitalSnap : snapshot.getChildren()) {
                    String hospitalId = hospitalSnap.getKey(); // H001, H002, etc.
                    String hospitalName = hospitalSnap.child("name").getValue(String.class);

                    if (hospitalName != null && hospitalId != null) {
                        // Store in multiple formats for better matching
                        String cleanName = hospitalName.toLowerCase().trim();
                        firebaseHospitalIds.put(cleanName, hospitalId);

                        // Also store without special characters
                        String simpleName = cleanName.replaceAll("[^a-z0-9\\s]", "");
                        firebaseHospitalIds.put(simpleName, hospitalId);

                        Log.d(TAG, "Stored: '" + hospitalName + "' → " + hospitalId);
                    }
                }

                firebaseDataLoaded = true;
                Toast.makeText(HomePage.this,
                        snapshot.getChildrenCount() + " hospitals in database",
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled( DatabaseError error) {
                Log.e(TAG, "Firebase error: " + error.getMessage());
                Toast.makeText(HomePage.this,
                        "Failed to load hospital data: " + error.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            mMap.setMyLocationEnabled(true);
            startLocationUpdates();
        }
    }

    private void startLocationUpdates() {
        LocationRequest request = LocationRequest.create();
        request.setInterval(10000);
        request.setFastestInterval(5000);
        request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.requestLocationUpdates(request, locationCallback, null);
        }
    }

    private void updateMapAndFetchHospitals(Location location) {
        LatLng userLatLng = new LatLng(location.getLatitude(), location.getLongitude());
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 14f));
        mMap.addMarker(new MarkerOptions().position(userLatLng).title("You are here"));

        updateAddressTextView(location);
        fetchNearbyHospitals(location.getLatitude(), location.getLongitude());
    }

    private void updateAddressTextView(Location location) {
        Geocoder geocoder = new Geocoder(this);
        try {
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            if (addresses != null && !addresses.isEmpty()) {
                String address = addresses.get(0).getAddressLine(0);
                currentAddressTextView.setText("Your Location: " + address);
            } else {
                currentAddressTextView.setText("Address not found");
            }
        } catch (Exception e) {
            currentAddressTextView.setText("Error: " + e.getMessage());
        }
    }

    private void fetchNearbyHospitals(double lat, double lng) {
        if (!firebaseDataLoaded) {
            Toast.makeText(this, "Please wait, loading database...", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
                + "?location=" + lat + "," + lng
                + "&radius=10000"
                + "&type=hospital"
                + "&key=" + API_KEY;

        Log.d(TAG, "Fetching hospitals from Google API...");

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    hospitalList.clear();
                    mMap.clear();

                    LatLng userLatLng = new LatLng(lat, lng);
                    mMap.addMarker(new MarkerOptions().position(userLatLng).title("You are here"));

                    try {
                        JSONArray results = response.getJSONArray("results");
                        Log.d(TAG, "Google API returned " + results.length() + " hospitals");

                        for (int i = 0; i < results.length(); i++) {
                            JSONObject obj = results.getJSONObject(i);
                            String name = obj.getString("name");
                            JSONObject loc = obj.getJSONObject("geometry").getJSONObject("location");
                            double hospitalLat = loc.getDouble("lat");
                            double hospitalLng = loc.getDouble("lng");
                            String placeId = obj.optString("place_id", "");

                            LatLng hospitalLatLng = new LatLng(hospitalLat, hospitalLng);
                            mMap.addMarker(new MarkerOptions().position(hospitalLatLng).title(name));

                            float[] resultsDistance = new float[1];
                            Location.distanceBetween(lat, lng, hospitalLat, hospitalLng, resultsDistance);
                            float distanceInKm = resultsDistance[0] / 1000f;
                            String formattedDistance = String.format("%.1f km", distanceInKm);

                            String status = "Status unknown";
                            if (obj.has("opening_hours")) {
                                JSONObject openingHours = obj.getJSONObject("opening_hours");
                                boolean isOpen = openingHours.optBoolean("open_now", false);
                                status = isOpen ? "Open" : "Closed";
                            }

                            // Match with Firebase hospital
                            String firebaseId = matchFirebaseHospital(name);

                            Hospital hospital = new Hospital(name, formattedDistance, status, placeId);
                            hospital.firebaseId = firebaseId;

                            hospitalList.add(hospital);

                            String matchStatus = (firebaseId != null) ? "✓ MATCHED" : "✗ NOT IN DB";
                            Log.d(TAG, matchStatus + " | " + name + " → " + firebaseId);
                        }

                        adapter.notifyDataSetChanged();

                        int matchedCount = 0;
                        for (Hospital h : hospitalList) {
                            if (h.firebaseId != null) matchedCount++;
                        }

                        Toast.makeText(this,
                                hospitalList.size() + " hospitals found (" + matchedCount + " in our database)",
                                Toast.LENGTH_LONG).show();

                    } catch (Exception e) {
                        Log.e(TAG, "Parse error: " + e.getMessage());
                        e.printStackTrace();
                        Toast.makeText(this, "Failed to parse hospital data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e(TAG, "API error: " + error.toString());
                    Toast.makeText(this, "Error fetching hospitals", Toast.LENGTH_SHORT).show();
                }
        );

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

    // Match Google API hospital name with Firebase
    private String matchFirebaseHospital(String googleName) {
        if (googleName == null) return null;

        String cleanName = googleName.toLowerCase().trim();

        // 1. Exact match
        if (firebaseHospitalIds.containsKey(cleanName)) {
            Log.d(TAG, "EXACT MATCH: " + googleName);
            return firebaseHospitalIds.get(cleanName);
        }

        // 2. Match without special characters
        String simpleName = cleanName.replaceAll("[^a-z0-9\\s]", "");
        if (firebaseHospitalIds.containsKey(simpleName)) {
            Log.d(TAG, "SIMPLE MATCH: " + googleName);
            return firebaseHospitalIds.get(simpleName);
        }

        // 3. Partial match (contains)
        for (Map.Entry<String, String> entry : firebaseHospitalIds.entrySet()) {
            String fbName = entry.getKey();

            // Check if either name contains the other
            if (cleanName.contains(fbName) || fbName.contains(cleanName)) {
                Log.d(TAG, "PARTIAL MATCH: '" + googleName + "' matched with '" + fbName + "'");
                return entry.getValue();
            }

            // Check word-by-word matching
            String[] googleWords = cleanName.split("\\s+");
            String[] fbWords = fbName.split("\\s+");
            int matchCount = 0;

            for (String gWord : googleWords) {
                for (String fbWord : fbWords) {
                    if (gWord.length() > 3 && fbWord.length() > 3 && gWord.equals(fbWord)) {
                        matchCount++;
                    }
                }
            }

            // If at least 2 significant words match, consider it a match
            if (matchCount >= 2) {
                Log.d(TAG, "WORD MATCH: '" + googleName + "' matched with '" + fbName + "' (" + matchCount + " words)");
                return entry.getValue();
            }
        }

        Log.d(TAG, "NO MATCH: " + googleName);
        return null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,  String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startLocationUpdates();
        } else {
            Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        fusedLocationClient.removeLocationUpdates(locationCallback);
    }
}