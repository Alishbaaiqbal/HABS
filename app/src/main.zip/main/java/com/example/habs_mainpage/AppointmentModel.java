package com.example.habs_mainpage;

public class AppointmentModel {
    public String patientName, contact, doctorName, specialization, date, timeSlot, fee;

    public AppointmentModel() {
        // empty constructor for Firebase
    }

    public AppointmentModel(String patientName, String contact, String doctorName,
                            String specialization, String date, String timeSlot, String fee) {
        this.patientName = patientName;
        this.contact = contact;
        this.doctorName = doctorName;
        this.specialization = specialization;
        this.date = date;
        this.timeSlot = timeSlot;
        this.fee = fee;
    }
}
