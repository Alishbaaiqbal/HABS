package com.example.habs_mainpage;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

//import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DoctorDetailsActivity extends AppCompatActivity {

    private static final String TAG = "DoctorDetailsActivity";
    private RecyclerView recyclerView;
    private DoctorAdapter doctorAdapter;
    private ArrayList<Doctor> doctorList;
    private DatabaseReference doctorRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doctordetails);

        recyclerView = findViewById(R.id.recycler_doctors);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        doctorList = new ArrayList<>();
        doctorAdapter = new DoctorAdapter(this, doctorList);
        recyclerView.setAdapter(doctorAdapter);

        // Get hospital details from intent
        String hospitalName = getIntent().getStringExtra("hospital_name");
        String hospitalId = getIntent().getStringExtra("hospitalId");

        Log.d(TAG, "Hospital Name: " + hospitalName);
        Log.d(TAG, "Hospital ID: " + hospitalId);

        if (hospitalId == null || hospitalId.isEmpty()) {
            Toast.makeText(this, "Hospital ID missing!", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Hospital ID is null or empty!");
            finish();
            return;
        }

        // Set title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(hospitalName != null ? hospitalName : "Doctors");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Firebase path
        doctorRef = FirebaseDatabase.getInstance()
                .getReference("Hospitals")
                .child(hospitalId)
                .child("Doctors");

        Log.d(TAG, "Firebase Path: " + doctorRef.toString());

        loadDoctors();
    }

    private void loadDoctors() {
        Toast.makeText(this, "Loading doctors...", Toast.LENGTH_SHORT).show();

        doctorRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot snapshot) {
                doctorList.clear();

                Log.d(TAG, "Snapshot exists: " + snapshot.exists());
                Log.d(TAG, "Number of doctors: " + snapshot.getChildrenCount());

                if (!snapshot.exists()) {
                    Toast.makeText(DoctorDetailsActivity.this,
                            "No doctors found for this hospital.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                for (DataSnapshot docSnap : snapshot.getChildren()) {
                    try {
                        Doctor doctor = docSnap.getValue(Doctor.class);
                        if (doctor != null) {
                            // Set ID from key
                            doctor.setId(docSnap.getKey());
                            doctorList.add(doctor);
                            Log.d(TAG, "Doctor loaded: " + doctor.getName());
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error parsing doctor: " + e.getMessage());
                        e.printStackTrace();
                    }
                }

                doctorAdapter.notifyDataSetChanged();

                if (doctorList.size() > 0) {
                    Toast.makeText(DoctorDetailsActivity.this,
                            doctorList.size() + " doctors loaded",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.e(TAG, "Database error: " + error.getMessage());
                Toast.makeText(DoctorDetailsActivity.this,
                        "Failed to load doctors: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}